#!/bin/bash

gcc t5p1.cpp -o main -lGL -lGLU -lglut -ldl -lm
./main