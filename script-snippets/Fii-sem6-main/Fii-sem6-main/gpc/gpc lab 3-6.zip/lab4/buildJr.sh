#!/bin/bash

gcc lab4jr.cpp -o main -lGL -lGLU -lglut -ldl -lm -lstdc++
./main