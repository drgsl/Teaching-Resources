#!/bin/bash

gcc t6p1.cpp -o main -lGL -lGLU -lglut -ldl -lm
./main