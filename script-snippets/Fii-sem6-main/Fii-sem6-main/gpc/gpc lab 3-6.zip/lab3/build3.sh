#!/bin/bash

gcc t3p3.cpp -o main -lGL -lGLU -lglut -ldl -lm
./main