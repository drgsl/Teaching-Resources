#!/bin/bash

gcc t3p2.cpp -o main -lGL -lGLU -lglut -ldl -lm -lstdc++
./main