#!/bin/bash

gcc t3p2Jr.cpp -o main -lGL -lGLU -lglut -ldl -lm -lstdc++
./main