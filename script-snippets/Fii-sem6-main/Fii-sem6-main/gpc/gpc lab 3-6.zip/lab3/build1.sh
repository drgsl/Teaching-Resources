#!/bin/bash

gcc t3p1.cpp -o main -lGL -lGLU -lglut -ldl -lm -lstdc++
./main