# pygame-tutorial-series
PyGame with Python tutorial series
http://pythonprogramming.net/pygame-python-3-part-1-intro/
